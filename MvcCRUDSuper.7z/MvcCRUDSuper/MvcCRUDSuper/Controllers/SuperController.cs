﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using MvcCRUDSuper.Utilerias;

namespace MvcCRUDSuper.Controllers
{
    public class SuperController : Controller
    {
        //
        // GET: /Super/

        public ActionResult New()
        {
            return View();
        }
        [HttpPost]
        public ActionResult New(int idsuper,string nombre,char sexo,string poder)
        {
            List<SqlParameter> parametros = new List<SqlParameter>();
            parametros.Add(new SqlParameter("@idsuper",idsuper));
            parametros.Add(new SqlParameter("@nombre", nombre));
            parametros.Add(new SqlParameter("@sexo",sexo));
            parametros.Add(new SqlParameter("@poder",poder));
            BaseHelper.ejecutarSentencia("Insert into Super values(@idsuper,@nombre,@sexo,@poder)", CommandType.Text, parametros);
            return View("Mensaje");
        }
        public ActionResult Update() 
        {
            return View();
        }
        [HttpPost]
        public ActionResult Update(int idsuper,string nombre,char sexo,string poder)
        {
            List<SqlParameter> parametros = new List<SqlParameter>(); 
            parametros.Add(new SqlParameter("@idsuper",idsuper));
            parametros.Add(new SqlParameter("@nombre",nombre));
            parametros.Add(new SqlParameter("@sexo",sexo));
            parametros.Add(new SqlParameter("@poder", poder));
            BaseHelper.ejecutarSentencia("Update Super set nombre=@nombre,sexo=@sexo,poder=@poder where idsuper=@idsuper", CommandType.Text, parametros);
            return View("Mensaje");
        
        }
        public ActionResult Delete() 
        {
            return View();
        }
        [HttpPost]
        public ActionResult Delete(int idsuper)
        {
            List<SqlParameter> parametros = new List<SqlParameter>();
            parametros.Add(new SqlParameter("@idsuper",idsuper));
            BaseHelper.ejecutarSentencia("Delete from super where @idsuper=idsuper",CommandType.Text,parametros);
            return View("Mensaje");
        }
        public ActionResult List() 
        {
            DataTable datosamostrar = new DataTable();
            datosamostrar=BaseHelper.ejecutarSelect("Select*from Super",CommandType.Text);
            ViewData["Super"] = datosamostrar;
            return View();
        }

    }
}
